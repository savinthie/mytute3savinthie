package com.company;
import java.util.*;
public class q3 {
    public static void main(String[] args) {
        int num;
        String letter;
        Scanner read=new Scanner(System.in);
        System.out.println("Enter a number : ");
        num= read.nextInt();
        System.out.println("Enter a letter : ");
        letter=read.next();
        for (int i=1;i<=num;i++){
            System.out.print(letter);


    }
}}
