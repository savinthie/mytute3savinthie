package com.company;
import java.util.*;
public class Main {

    public static void main(String[] args) {
    /* question 1.....
        int count = 0;
        do
        {
            System.out.print(" Hello ");
            count = count + 1;
        }while (count < 9);
        System.out.println();

question 2....
int num1, num2;
        Scanner read = new Scanner(System.in);
        System.out.print("first number : ");
        num1 = read.nextInt();
        System.out.print("second number : ");
        num2 = read.nextInt();
        if (num1 <= num2) {
            int i = num1 - 1;
            int j = num2 - 1;
            while (i <= j) {
                System.out.println(i);
                i++;
            }


        } else {
            System.out.println("first number is greater than the second one...Try again!");
        }

question 3.....

    int num;
    String letter;
    Scanner read=new Scanner(System.in);
        System.out.print("Enter a number : ");
    num= read.nextInt();
        System.out.print("Enter a letter : ");
    letter=read.next();
    for (int i=1;i<=num;i++){
        System.out.print(letter);
    }
*/

}}

