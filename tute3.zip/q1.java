package com.company;

public class q1 {
    public static void main(String[] args) {
    int count = 0;
        do
    {
        System.out.print(" Hello ");
        count = count + 1;
    }while (count < 9);
        System.out.println();
}}
